package com.example.tienda

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.tienda.databinding.ItemProductBinding
import com.example.tienda.entities.Product
import com.example.tienda.repository.ProductRepository
import kotlinx.coroutines.*


@Suppress("MemberVisibilityCanBePrivate")
class ProductAdapter (private val list: List<Product>) :

RecyclerView.Adapter<ProductAdapter.ProductsViewHolder>() {


    class ProductsViewHolder(val binding: ItemProductBinding) :
        RecyclerView.ViewHolder(binding.root)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductsViewHolder {
        val binding = ItemProductBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProductsViewHolder(binding)
    }
    override fun onBindViewHolder(holder: ProductsViewHolder, position: Int) {
        with(holder.binding) {
            tvProduct.text = list[position].name
            tvPrice.text = list[position].price.toString()
            tvCant.text = list[position].cant.toString()
            btnClean.setOnClickListener {
                val repository = ProductRepository.getRepository(context = AddProductActivity())
               CoroutineScope(Dispatchers.IO).launch{
                    repository.deleteid(list[position].id)

                }}
        }
    }

    override fun getItemCount(): Int = list.size
}
