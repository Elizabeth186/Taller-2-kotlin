package com.example.tienda.repository

import com.example.tienda.AddProductActivity
import com.example.tienda.dao.ProductDao
import com.example.tienda.database.ProductRoomDatabase
import com.example.tienda.entities.Product
import kotlinx.coroutines.flow.Flow

class ProductRepository (private val productDao: ProductDao){
    companion object {
        private var INSTANCE : ProductRepository? = null
        fun getRepository(context: AddProductActivity) : ProductRepository {
            return INSTANCE ?: synchronized(this) {
                val database = ProductRoomDatabase.getDatabase(context)
                val instance = ProductRepository(database.productDao())
                INSTANCE = instance
                instance
            }
        }
    }

    val allProduct: Flow<List<Product>> = productDao.getAlphabetizedVehicles()

    suspend fun insert(product: Product) {
        productDao.insert(product)
    }
    suspend fun deleteid(Id:Int) {

    }





}