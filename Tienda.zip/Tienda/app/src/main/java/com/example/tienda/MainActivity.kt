package com.example.tienda

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.example.tienda.databinding.ActivityMainBinding
import com.example.tienda.repository.ProductRepository
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        buildList()
        addListeners()
    }

    private fun buildList() {

        val repository = ProductRepository.getRepository(this)

        val layoutManager = GridLayoutManager(this, 1)

        lifecycleScope.launch {
            repository.allProduct.collect { product ->
                binding.rvProduct.apply {
                    adapter = ProductAdapter(product)
                    setLayoutManager(layoutManager)
                }
            }
        }
    }

    private fun addListeners() {
        binding.fbAdd.setOnClickListener {
            startActivity(Intent(this, AddProductActivity::class.java))
        }

        }
    }
